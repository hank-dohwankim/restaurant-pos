package com.system.restaurant.domain;

public class Order {

    private int order_id;
    private int table_no;
    private String waiter;
    private String message;
    private String cookig_status;

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getTable_no() {
        return table_no;
    }

    public void setTable_no(int table_no) {
        this.table_no = table_no;
    }

    public String getWaiter() {
        return waiter;
    }

    public void setWaiter(String waiter) {
        this.waiter = waiter;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCookig_status() {
        return cookig_status;
    }

    public void setCookig_status(String cookig_status) {
        this.cookig_status = cookig_status;
    }
}
